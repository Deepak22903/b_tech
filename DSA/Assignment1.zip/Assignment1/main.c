#include <stdio.h>
#include "DSA_Assignment1.1.h"
#include "DSA_Assignment1.2.h"
#include "DSA_Assignment1.3.1.h"
#include "DSA_Assignment1.3.2.h"
#include "DSA_Assignment1.4.h"
#include "DSA_Assignment1.5.h"
#include "DSA_Assignment1.6.h"
#include "DSA_Assignment1.7.h"


int main(){

    printf("\n************************************\n");

    //size();

    printf("\n************************************\n");

    //largest();

    printf("\n************************************\n");

    //vowel_1();

    printf("\n************************************\n");

    //vowel_2();

    printf("\n************************************\n");

    //da();

    printf("\n************************************\n");

    //fah_to_cel();

    printf("\n************************************\n");

    //circle();

    printf("\n************************************\n");

    day();

    printf("\n************************************\n");

    return 0;
}